#!/usr/bin/python3
def pow(a, b):
    power = a ** b
    return power
