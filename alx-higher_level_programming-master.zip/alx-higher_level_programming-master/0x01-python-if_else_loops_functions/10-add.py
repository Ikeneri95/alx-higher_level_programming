#!/usr/bin/python3
def add(a, b):
    cal = a + b
    return cal
