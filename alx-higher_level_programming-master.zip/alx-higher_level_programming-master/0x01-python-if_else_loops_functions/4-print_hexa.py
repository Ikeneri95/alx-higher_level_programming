#!/usr/bin/python3
for i in range(0, 99):
    print("{} = {}".format(i, hex(i)))
