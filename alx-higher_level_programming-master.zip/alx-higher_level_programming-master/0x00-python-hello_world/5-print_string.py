#!/usr/bin/python3
str = "Holberton School"
print(f"{3 * str}")
print(f"{str[:9]}")
